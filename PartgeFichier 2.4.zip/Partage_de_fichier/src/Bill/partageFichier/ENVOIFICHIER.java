package Bill.partageFichier;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.*;
import javax.imageio.stream.FileImageInputStream;
import javax.net.ssl.HostnameVerifier;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

@SuppressWarnings("unused")
public class ENVOIFICHIER extends JFrame implements ActionListener, WindowListener {
	/* @Author Bile Bernard */
	private static final long serialVersionUID = 1L;
	static String chaine = "";
	static long start, fin;
	static String debit = "", Tempsrestant = "";

	//static JLabel chaineAutre = new JLabel();
	private String NumPortfich = "NumPortfich.txt";// fichier qui va memoriser
													// le numero de port
													// d'ecoute
	// pour permettre qu'il soit modifier � sa guise
	private int portEcoute;
	private static int limit = 64000;
	private static final int portPardefaut = 64000;
	// port d'ecoute pour la reception du fichier par defaut
	private JButton Ouvrir;
	private static JButton Envoyer;
	private static JTextArea adresse;
	private static JTextField url;// url du fichier � envoyer
	static JButton pross = new JButton();
	private JMenuItem historique;
	private JMenuItem _32000_octet;
	private JMenuItem _64000_octet;
	private JMenuItem _16000_octet;
	private JMenuItem _8000_octet;
	private JMenuItem _1000_octet;
	private JMenuItem changerNumPort;
	private JMenuItem evolutionReception = new JMenuItem("voir l'evolution de la reception");
	private JMenuItem fermer;
	private static JLabel tempslabel = new JLabel();
	private static JLabel debitlabel = new JLabel();
	static JProgressBar[] barprogression = new JProgressBar[2];
	static JLabel[] labelprogresbas = new JLabel[2];
	static Checkbox[] box = new Checkbox[2];
	private static Hashtable<String, String> controle = new Hashtable<String, String>();
	private static double tempsestim� = 0;
	private static float gh;
	private static long compteurd = 0;

	// --------------------------------Construction--------------------------------------------------
	@SuppressWarnings("deprecation")
	public void initialisation(String s, String s2) throws IOException {
	//	super((new StringBuilder("B&G FDFTS 1.1.9.0 ")).append((new Date()).toLocaleString()).toString());

		Ouvrir = new JButton("Selectionner");
		Envoyer = new JButton("Envoyer");
		adresse = new JTextArea();

		url = new JTextField();
		JMenuItem chercherserveur = new JMenuItem("cherche s'il y'a d'autre serveur");

		adresse.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
			}

			@Override
			public void keyPressed(KeyEvent e) {
				boolean t = (e.getKeyCode() == 'H' || e.getKeyCode() == 'h') && e.isControlDown();
				if (t) {
					try {
						Vector<String> tt = listeHoteLocal();
						if (tt.size() > 0) {
							adresse.setText(tt.get(0));
							for (int j = 1; j < tt.size(); j++)
								adresse.setText(adresse.getText() + ";" + tt.get(j));
							String s = adresse.getText(); 
							if (s.indexOf(';') <= 1)
								adresse.setText(s.substring(s.indexOf(';' + 1, s.length())));
						}
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		historique = new JMenuItem("Historique d'envoi reception");
		fermer = new JMenuItem("quitter");
		changerNumPort = new JMenuItem("changer le port d'ecoute");
		_64000_octet = new JMenuItem("taille maxi du paquet:64KO");
		_32000_octet = new JMenuItem("taille maxi du paquet:32KO");
		_16000_octet = new JMenuItem("taille maxi du paquet:16KO");
		_8000_octet = new JMenuItem("taille maxi du paquet:8KO");
		_1000_octet = new JMenuItem("taille maxi du paquet: 1KO");
		final JMenu host = new JMenu("listedes hosts");

		JMenu changerLimitTranfert = new JMenu("changer la taille du paquet");
		changerLimitTranfert.add(_1000_octet);
		changerLimitTranfert.add(_8000_octet);
		changerLimitTranfert.add(_32000_octet);
		changerLimitTranfert.add(_64000_octet);
		changerLimitTranfert.add(host);

		setLayout(new GridLayout(2, 1));
		JPanel pan1 = new JPanel();
		add(pan1);
		pan1.setLayout(new GridLayout(2, 1));
		pan1.setBackground(new Color(27, 228, 203));
		JPanel deb = new JPanel();
		deb.setLayout(new GridLayout(2, 1));
		pan1.add(deb);
		deb.add(new JLabel(
				"<html><h3><font color=red>Entrez le(s) nom(s) ou l'IP <br>de(s) (la) machine(s) destination:a.b.c.d ;a'.b'.c'.d'</font></h1></html>"));
		JPanel pane = new JPanel();
		deb.add(pane);
		pane.setLayout(new GridLayout(1, 2));
		pane.add(debitlabel);
		pane.add(tempslabel);
		pan1.add(adresse);
		JPanel pan = new JPanel();
		JPanel panhaut = new JPanel();
		JPanel pansud = new JPanel();
		add(pan);
		pan.setLayout(new GridLayout(2, 1));
		pan.add(panhaut);
		pan.add(pansud);
		pansud.setLayout(new GridLayout(1, 1));
		pansud.setBackground(new Color(167, 88, 165));
		panhaut.setLayout(new GridLayout(2, 1));
		JPanel panprogress = new JPanel();
		panprogress.setLayout(new GridLayout(2, 2));
		pansud.add(panprogress);
		CheckboxGroup boxgroup = new CheckboxGroup();
		for (int j = 0; j < barprogression.length; j++) {
			barprogression[j] = new JProgressBar();
			box[j] = new Checkbox(((j == 0) ? "envoi de dossier" : "envoi de fichier"), false, boxgroup);
			barprogression[j].setStringPainted(true);
			barprogression[j].setVisible(true);
			labelprogresbas[j] = new JLabel();
			panprogress.add(labelprogresbas[j]);
			panprogress.add(barprogression[j]);
		}

		JPanel ss = new JPanel();
		panhaut.add(ss);
		ss.setLayout(new GridLayout(1, 2));
		ss.add(url);
		ss.add(Ouvrir);

		JPanel tt = new JPanel();
		panhaut.add(tt);
		tt.setLayout(new GridLayout(1, 3));
		tt.add(box[0]);
		tt.add(box[1]);
		tt.add(Envoyer);
		box[0].addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent arg0) {
				if (url.getText().compareToIgnoreCase("") != 0 && url.getText() != null) {
					url.setText(new File(url.getText()).getParent());
					box[1].setState(true);
				}
			}
		});
		panhaut.setBackground(new Color(123, 200, 230));
		adresse.setFont(new Font("SanSerif", 1, 20));
		adresse.setToolTipText(
				"<html>donner l'adresse IP de la machine distante<br>Utiliser des <h1>;<br></h1> pour cas d'envoi multipe<br>vous pouvez specifier le numero de port destination <br>par<h1> @ip:numport</h1><br>CTRL +H pour ajouter <br> les ordi du reseau local</html>");
		Ouvrir.setFont(new Font("SanSerif", 1, 15));
		Envoyer.setFont(new Font("SanSerif", 1, 15));
		Envoyer.addActionListener(this);
		addWindowListener(this);
		Ouvrir.addActionListener(this);
		fermer.addActionListener(this);
		historique.addActionListener(this);
		_1000_octet.addActionListener(this);
		_8000_octet.addActionListener(this);
		_16000_octet.addActionListener(this);
		_64000_octet.addActionListener(this);
		_32000_octet.addActionListener(this);
		changerNumPort.addActionListener(this);
		JMenuBar bar = new JMenuBar();
		JMenu Fichier = new JMenu("FIchier");
		JMenu HISTORIQUE = new JMenu("HIstorique");
		Fichier.add(fermer);
		Fichier.add(chercherserveur);
		fermer.setToolTipText("quitter l'application");
		Fichier.add(changerNumPort);
		Fichier.add(changerLimitTranfert);
		changerNumPort.setToolTipText("changer le port d'�coute");
		HISTORIQUE.add(historique);
		HISTORIQUE.addSeparator();
		HISTORIQUE.add(evolutionReception);
		evolutionReception.addActionListener(this);
		historique.setToolTipText("ouvrir l'historique d'envoi et reception");
		url.setToolTipText("selectionner un fichier");
		bar.add(Fichier);
		bar.add(HISTORIQUE);
		setJMenuBar(bar);
		Fichier.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				System.out.println("�a marche iic pressed");
			}

			@Override
			public void mouseExited(MouseEvent e) {
				Vector<String> hoste;
				try {
					hoste = listeHoteLocal();
					final JCheckBoxMenuItem[] men = new JCheckBoxMenuItem[hoste.size()];
					for (int j = 0; j < men.length; j++) {
						men[j] = new JCheckBoxMenuItem(hoste.get(j));
						host.add(men[j]);
						final int k = j;
						men[j].addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								String texte = men[k].getText();
								if (adresse.getText() != "") {
									adresse.setText(adresse.getText() + ";" + texte);
								} else
									adresse.setText(texte);
							}
						});
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		setResizable(false);
		setIconImage((new ImageIcon("bi.jpg")).getImage());
		{
			File f = new File("HISTORIQUE.txt");
			if (!f.exists())
				new FileOutputStream(f);
		}
		setVisible(false);
		if (s != null && s2 != null) {
			url.setText(s);
			adresse.setText(s2);
			Envoyer.doClick();

		} else if (s != null) {
			url.setText(s);
			System.out.println("donner l'adresse du (des) destinataire separer par\n des points virgules:");
			adresse.setText(new Scanner(System.in).nextLine());
			Envoyer.doClick();
		} else {
			setVisible(true);
		}
	}

	// -----------------------------------------fin constructeur-----------------------------------------------------------
	// -------------------------------------------------------------main----------------------------------------------------
	public static void main(String args[]) throws IOException {
		// listeHoteLocal();
		try {
				 ENVOIFICHIER initialisation = new ENVOIFICHIER();
				 initialisation.initialisation(null, null);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	// ---------------------------------------------------------------------------------------------------
	@SuppressWarnings({ "deprecation", "resource" })
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == _1000_octet)
			limit = 1000;
		else if (e.getSource() == evolutionReception)
			pross.doClick();
		else if (e.getSource() == _8000_octet)
			limit = 8000;
		else if (e.getSource() == _32000_octet)
			limit = 32000;
		else if (e.getSource() == _64000_octet)
			limit = 64000;
		if (e.getSource() == fermer) {
			try {
				new PrintStream(new FileOutputStream(this.NumPortfich)).println(("" + this.portEcoute).trim());
				//new PrintStream(new FileOutputStream("HISTORIQUE.TXT")).println((chaine + chaineAutre.getText()));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				System.out.println("erreur d'enregistrement du num port");
			}
			System.exit(0);
		}
		if (e.getSource() == this.changerNumPort) {
			String g = JOptionPane.showInputDialog(this,
					"<html>donner le nouveau port (1 � 65536)<br>port actuel:<h3>" + this.portEcoute + "</h3></html>");
			if (g != null && !g.equals("")) {
				int h = Integer.parseInt(g);
				if (h > 0 && h <= 65536)
					this.portEcoute = h;
			}
			System.out.println(this.portEcoute);
		}/*
		if (e.getSource() == historique) {
			File f = new File("HISTORIQUE.txt");
			if (f.exists()) {
				//String texte = "<html>" + chaine + chaineAutre.getText() + "</html>";
				final JFrame FET = new JFrame("Informations Historique");
				FET.setSize(600, 600);
				FET.setResizable(false);
				JScrollPane scroller = new JScrollPane(new JLabel(texte));
				scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
				scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scroller.setPreferredSize(new Dimension(300, 150));
				scroller.setBorder(BorderFactory
						.createCompoundBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(""),
								BorderFactory.createEmptyBorder(1, 1, 1, 1)), scroller.getBorder()));
				FET.add("Center", scroller);
				final JButton b = new JButton("Quitter");
				FET.add("South", b);
				b.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						FET.dispose();
					}
				});
				FET.show();
			}
		}*/
		if (e.getSource() == Ouvrir) {
			FileSystemView fsv = FileSystemView.getFileSystemView();
			JFileChooser fileChooserSaveImage = new JFileChooser(fsv.getRoots()[0]);
			if (box[0].getState()) {// pour envoyer un dossier
				box[1].setState(true);
				fileChooserSaveImage.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

			}
			int retour = fileChooserSaveImage.showOpenDialog(this);
			if (retour == 0) {
				File url1 = fileChooserSaveImage.getSelectedFile();
				if (url1.exists()) {
					if (box[0].getState())
						url.setText(url1.getParent());
					else
						url.setText(url1.getAbsolutePath());
				}
				else
					JOptionPane.showMessageDialog(null, "fichier corrompu!!");
			}
		} else if (e.getSource() == Envoyer)
			if (adresse.getText().compareToIgnoreCase("") == 0)
				JOptionPane.showMessageDialog(null, "<html><h1>le champ adresse est vide!!</h1></html>");
			else if (url.getText().compareToIgnoreCase("") == 0) {
				JOptionPane.showMessageDialog(null,
						"<html><h1>aucun fichier n'a \351t\351 selectionn\351!!</h1></html>");
			} else {
				String adr = adresse.getText();
				String add[] = (String[]) null;
				if (adr.indexOf(";") > 0) {
					StringTokenizer tt = new StringTokenizer(adr, ";");
					int l = tt.countTokens();
					add = new String[l];
					for (int j = 0; tt.hasMoreTokens(); j++)
						add[j] = tt.nextToken();
				} else {
					add = new String[1];
					add[0] = adr;
				}
				//new ServeurProcessus(url.getText(), adr);
			}
		System.out.println(limit);
	}
	// ============================fonction envoyer=========

	public void windowActivated(WindowEvent windowevent) {
	}

	public void windowClosed(WindowEvent arg0) {
		System.exit(0);
	}

	public void windowClosing(WindowEvent arg0) {
		// on enregistre le numero de port
		this.fermer.doClick();
		// new PrintWriter(new FileOutputStream()).println(chaine);
		System.exit(0);
	}

	public void windowDeactivated(WindowEvent windowevent) {
	}

	public void windowDeiconified(WindowEvent windowevent) {
	}

	public void windowIconified(WindowEvent windowevent) {
	}

	@SuppressWarnings("resource")
	public void windowOpened(WindowEvent arg0) {

		// this.setVisible(false);
		// JOptionPane.showMessageDialog(null, "<html><h1><font
		// color=blue><br><br>WELCOME IN MY
		// PROGRAMME<br><BR></font></h1></html>");

		// on recup�re e numero de port
		try {

			int po = Integer.parseInt(new BufferedReader(new FileReader(this.NumPortfich)).readLine());
			chaine = new BufferedReader(new FileReader("HISTORIQUE.txt")).readLine();
			this.portEcoute = po;// .nextInt();
			System.out.println(po);
		} catch (Exception e) {
			System.out.println("ERREUR dOnc par defaut");
			this.portEcoute = portPardefaut;// en cas d'erreur de lecture on
											// utilise le port par defaut
		}
		setSize(600, 500);// la taille de la fenetre
		// pour centrer la fenetre
		Dimension dimensionecran = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dimensionecran.width - this.getWidth()) / 2, (dimensionecran.height - this.getHeight()) / 2);
		this.setVisible(true);
		// this.pack();
		new ClientProcessus(this.portEcoute);//, chaineAutre, pross);
		// pross.doClick();
	}
	// -----------------------------------------envoi
	// fichier------------------------------------------------------------------------------------

	// --------------------------------------------fin
	// envoifichier-----------------------------------------------------------------------------

	// -----------------------------------------envoi
	// dossier----------------------------------------------------------------------------------

	private static String taillepro(long compteur) {
		String res = null;
		// TODO Auto-generated method stub
		if (compteur < 1024)
			res = (compteur + "\t Octets");
		else if (compteur < 1048576)
			res = ((float) (compteur * 1. / (1024)) + "\t KO");
		else if (compteur < 1073741824)
			res = ((float) (compteur * 1. / (1048576)) + "\t MO");
		else
			res = ((float) (compteur * 1. / (1073741824)) + "\t GO");
		return res;
	}

	private static long tailleDossier(Vector<String> f, int offset) {
		// TODO Auto-generated method stub
		long x = 0;
		for (int j = offset; j < f.size(); j++)
			x += new File(f.get(j)).length();
		return x;
	}

	private static Vector<String> lister(String dossier) {
		// TODO Auto-generated method stub
		Vector<String> fichiers = new Vector<String>();
		lister(dossier, fichiers);
		return fichiers;
	}

	private static String[] retournerBase(Vector<String> fichiers, String dossier) {
		// TODO Auto-generated method stub
		int n = fichiers.size();
		String chaine[] = new String[n];

		for (int j = 0; j < n; j++) {
			String s = new File(fichiers.get(j)).getParent();
			if (s.endsWith(dossier))
				chaine[j] = dossier;
			else {
				boolean test = false;
				String val = "";
				StringTokenizer tt = new StringTokenizer(s, "\\");
				while (tt.hasMoreTokens()) {
					String p = tt.nextToken();
					if (p.compareToIgnoreCase(dossier) == 0)
						test = true;
					if (test)
						val += p + File.separator;
				}
				chaine[j] = val.substring(0, val.length() - 1);
			}
		}
		return chaine;
	}

	private static void lister(String dossier, Vector<String> lisfichier) {
		File f = new File(dossier);
		File[] ll = f.listFiles();
		for (int j = 0; j < ll.length; j++) {
			if (ll[j].isFile())
				lisfichier.add(ll[j].getAbsolutePath());
			else {
				if (ll[j].canRead())
					lister(ll[j].getAbsolutePath(), lisfichier);
			}
		}
	}

	public static Vector<String> listeHoteLocal() throws IOException {
		Vector<String> l = new Vector<String>();
		Process pb = Runtime.getRuntime().exec("net view");
		BufferedReader in = new BufferedReader(new InputStreamReader(pb.getInputStream()));

		String s;

		while (!procDone(pb)) {
			while ((s = in.readLine()) != null) {
				if (s.startsWith("\\\\")) {
					StringTokenizer tok = new StringTokenizer(s);
					while (tok.hasMoreTokens()) {
						s = tok.nextToken();
						s = s.substring(s.lastIndexOf("\\") + 1);
						l.add(s);
						System.out.println(s);
						break;
					}
				}
			}
		}

		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return l;

	}

	private static boolean procDone(Process p) {
		try {
			int v = p.exitValue();
			return true;
		} catch (IllegalThreadStateException e) {
			return false;
		}

	}
}
