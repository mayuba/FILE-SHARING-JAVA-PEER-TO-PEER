package Bill.partageFichier;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JOptionPane;

public class ServeurProcessus extends Thread {
	String fich = null, add = null;

	static Vector<Float> listeDebit = new Vector<Float>();
	private static final int portPardefaut = 64000;
	private static int limit = 64000;
	private static float gh;
	private static long compteurd = 0;
	private   int nbrhost;

	public int port;

	private static long start;

	public ServeurProcessus(String fich, String add,int port) {
		this.fich = fich;
		this.add = add;
		this.port=port;
		start();
	}

	@SuppressWarnings("deprecation")
	public void run() {
		/*
		 * try { if (new File(fich).isDirectory()) { //
		 * JOptionPane.showMessageDialog(null,"<html><h1><font // color=blue>ce
		 * fichier est un <br>dossier // !!</font></h1></html>"); int y =
		 * JOptionPane.showConfirmDialog(null,
		 * "voulez-vous envoyez le dossier::" + new File(fich).getName() + "?",
		 * "Confirmation", JOptionPane.YES_NO_OPTION); if (y == 0)
		 * //ENVOIFICHIER.envoiDossier(fich, add);
		 * 
		 * yield(); stop(); } int y = JOptionPane.showConfirmDialog(null,
		 * "voulez-vous envoyez le fichier::" + new File(fich).getName() + "?",
		 * "Confirmation", JOptionPane.YES_NO_OPTION);
		 * 
		 * if (y == 0) // ENVOIFICHIER.envoiFichier(fich, add, 100, " ", " ",
		 * " ");// yield(); stop(); } catch (IOException e) { // TODO
		 * Auto-generated catch block System.out.println(e); }
		 */
		try {
			Transfert(fich, add,port, 100);//, " ", " ", " ");
			yield();
			stop();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

	}

	@SuppressWarnings("deprecation")
	public static boolean Transfert(String fich, String host,int port, int type)//, String etat, String dossier, String sous) // type:100
			// fichier
			// ,101
			// dossier
			throws IOException {
		// pross.doClick();
		/*
		if (!new File(fich).isDirectory()) {
			boolean testfile = true;
			if (fich.startsWith("http"))
				testfile = false;
				*/
			// controle.put("controle", "true");
			// adresse.setVisible(false);
			//if (testfile)
				/*
				 * labelprogresbas[1].setText(
				 * "<html><font color=blue>evolution de l'envoi du fichier:<br>"
				 * + new File(fich).getName() + "</font></html>");
				 */
				//nbrhost = host.length;
			//float evolution = 0;

			File  
			//if (testfile)
				fichier = new File(fich);
				//System.out.println(nbrhost);
			// ------------------------------------------socket-----------------------------------------------------------------
			//Socket s[] = new Socket[nbrhost];
			Socket s = null ;//= new Socket();
			//OutputStream out[] = new OutputStream[nbrhost];
			OutputStream out = null;// = new OutputStream();
			//BufferedInputStream response[] = new BufferedInputStream[nbrhost];
			BufferedInputStream response = null;
			//for (int j = 0; j < nbrhost; j++)// l'nevoi paralelle par creation
			// des differents flux d'entr�e
			// sortie
			//{
				 
				 
					//host[j] = host[j].trim();
					//host[j] = host.trim();
					/*if (host[j].indexOf(":") > 0) // on teste si on a indiqu� un
					// port d'ecoute sur l'hote
					{
						StringTokenizer tt = new StringTokenizer(host[j], ":");
						host[j] = tt.nextToken();
						portdest = Integer.parseInt(tt.nextToken());
						// System.out.println(host[j]+":"+portdest);
					}*/
					 
					//s[j] = new Socket(host[j], portdest);
					s = new Socket(host, port);
					response = new BufferedInputStream(s.getInputStream());
					out = s.getOutputStream();
					//response[j] = new BufferedInputStream(s[j].getInputStream());
					//out[j] = s[j].getOutputStream();
				 
			//}
			// ----------------------------------------------------------------fin
			// socket----------------------------------------
			long taillefichier = 0;
			//if (testfile)
				taillefichier = fichier.length();

			//long blocEnvoi = taillefichier / 64000L;
			// System.out.println((new StringBuilder("nombre de pas
			// suppos\351:")).append(blocEnvoi).toString());

			String extension = null;
			//boolean envoid = false;
			if (type == 100) //{ cas d'un fichier
				// tempslabel.setText("transfert en cours...");
				//if (testfile)
					//extension = "F_:" + fichier.getName() + ":" + taillefichier;
			     extension = fichier.getName() + ":" + taillefichier;
				/*else
					extension = "F_:" + new URL(fich).getFile().substring(new URL(fich).getFile().lastIndexOf("/") + 1)
							+ ":" + taillefichier;*/
			/*} else {
				extension = "DOS_:" + etat + ":" + dossier + ":" + sous + ":" + fichier.getName() + ":" + taillefichier;//
				envoid = true;
			}*/
			System.out.println("paquet � envoyer:" + extension);
			byte nameFile[] = extension.getBytes();// recuperation du nom du fichier
			// suivie de l'envoi aux hotes

			//for (int i = 0; i < nbrhost; i++)
				//if (s[i].isConnected())
				//	out[i].write(lo, 0, lo.length);
				
				if (s.isConnected())
					out.write(nameFile, 0, nameFile.length);
				/**
				 * systeme de crytage a installer ici
				 */
				response.read();
				// ici on
			//response[(int) ((nbrhost - 1) * Math.random())].read();// ici on
			// peux
			// juste
			// attendre
			// un
			// petit
			// temps
			// avant
			// de
			// commencer
			// �
			// envoyer

			// System.out.println("pret � envoyer////"+x+" nbr:"+nbrhost);
			//if (type != 101)
			//	JOptionPane.showMessageDialog(null, "envoi  en cours.....");
			byte donnee[] = new byte[limit];
			//long compteurcourant = 0;

			int size;
			start = System.currentTimeMillis();// pour le calcul du debit

			InputStream in = null;
			//if (testfile)
				in = fichier.toURL().openStream();
			//else
			//	in = new URL(fich).openStream();
			while ((size = in.read(donnee)) != -1) // tant que c'est pas la fin du
			// fichier
			{
				// debitlabel.setText("<html>" + debit + "<br> </html>");
				//if (thereNotConnected(s))
					//break;// test si aucun des hote n'est joingnable
				//compteurcourant += size;
				//for (int j = 0; j < nbrhost; j++)// envoi des bloc d'octets aux
					// destinataires
					if (s.isConnected())
						out.write(donnee, 0, size);
				//if (envoid) compteurd += size;
				// fin=System.currentTimeMillis();
				// debit=String.valueOf(((float) 8*compteurcourant/(1000* (fin -
				// start)))+" Mbits/S");
				// tempsestim�=(float)((8*compteurcourant)/Integer.parseInt((new
				// StringTokenizer(debit).nextToken())));
				//if (testfile)
				//	evolution = ((100 * compteurcourant) / taillefichier);// au
				// cas
				// ou
				// on
				// utiliseur
				// un
				// JProgressBar
				//else
				//	evolution = 0;
				// barprogression[1].setValue((int) evolution);
				// barprogression[1].setString(barprogression[1].getValue() +
				// "%");
				// System.out.println("envoi:"+evolution+"%");
			}
			in.close();
			// adresse.setVisible(true);

			// fin = System.currentTimeMillis();
			// long T = fin - start;// temps d'envoi des octets pour le calcul
			// du
			// debit
			// System.out.println("temps ecoul�:" + T);
			// --------------------nommer la vitesse de
			// transfert----------------
			/*
			 * if (T > 0) { float gh1 = (float) ((8 * compteurcourant) * 1. /
			 * (1000 * (T)));// Mbits
			 * 
			 * listeDebit.add(gh1);// memoire sur le debit pour une moyenne if
			 * (gh1 < 0.1) debit = (gh1 * 1000) + "   .Kbits/S"; else debit =
			 * (gh1) + "   Mbits/S"; }
			 */
			//gh = debitMoyen(listeDebit);
			/*
			 * if (!envoid) tempslabel.setText("fin"); { tempsestim�= (double)
			 * (.000001d*((8*fichier.length())*1./gh)); int ss=(int)
			 * (tempsestim� %60),min=(int) ((tempsestim�/60) %60),h=min/60;
			 * 
			 * Tempsrestant =((h>0)?h +"  h  ":"")+((min>0)? min+" mn   "
			 * :"")+((ss>0)? ss +" S":""); tempslabel.setText(
			 * "<html><h3>temps estim�: " +Tempsrestant+"</h3></html>"); }
			 */
			// tempsestim�=(float)((8*(taillefichier-compteurcourant))*1./(1000000*Integer.parseInt((new
			// StringTokenizer(debit).nextToken()))));
			// debitlabel.setText("<html>" + debit + "<br>" + "</html>");
			// tempslabel.setText("");

			// fin de l'envoi ... je lib�re les ressource
			//for (int j = 0; j < nbrhost; j++) {
				out.flush();
				s.close();
			//}

			// System.out.println("fin d'envoi");
			/*
			 * chaine += (new StringBuilder("<h1>NOM FICHIER:")).append(
			 * "<font color=red>" + fich + "</font>")
			 * .append("<br>DESTINATAIRE:").append("<font color=blue>" +
			 * adresse.getText() + "</font>") .append("<br>Date d'envoi:"
			 * ).append("<font color=blue>" + (new Date()).toGMTString() +
			 * "</font>") .append("</h1></br>").toString();
			 * 
			 * controle.clear();
			 */
			// barprogression[1].setValue(0);
			// barprogression[1].setString(barprogression[1].getValue() + "%");
			// labelprogresbas[1].setText("");
			return true;
		//}
	//	return false;
	}

	/**
	 * @param debit
	 * @return
	 */
	public static float debitMoyen(Vector<Float> debit) {
		// TODO Auto-generated method stub
		int n = debit.size();
		float s = 0;
		int j = 0;
		while (j < n) {
			s += debit.get(j);
			j++;
			System.out.println(s);
		}
		return ((float) (s * 1. / n));
	}

/*	private static boolean thereNotConnected(Socket[] s) {

		boolean rs = true;
		for (int j = 0; j < s.length; j++) {
			rs = rs && (!s[j].isConnected());
			System.out.println(s[j] + "  thereNotConnecter verification");
		}
		return rs;
	}
	
	*/	
}
