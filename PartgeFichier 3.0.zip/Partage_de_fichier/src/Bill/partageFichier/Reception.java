package Bill.partageFichier;

import java.awt.Desktop;
import java.awt.FlowLayout;
import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.filechooser.FileSystemView;
public class Reception extends Thread {
	private Socket soc;
	private OutputStream write;
	private BufferedInputStream read;
	private String copy;
	private String nomFichier;
	private String dossierenregistrement = null;
	Hashtable<String, String> listeDossierEncours = null;
	
	//Vector<String> listereception = null;
	long taillefichier = 0;

	public Reception(Socket soc)  {
		this.soc = soc;
		try {
			read = new BufferedInputStream(this.soc.getInputStream());
		 
		write = soc.getOutputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block

			JOptionPane.showMessageDialog(null,
					("Reception erreur"));
		}
		start();
		
	}

	public void run() {
		try {
			byte b[] = new byte[1000];
			 //exception
				read.read(b);
			// selection du dossier d'enregistrement
			copy = (new String(b, 0, b.length)).trim();//on renvoie une copie au propre
		
			StringTokenizer tt = new StringTokenizer(copy, ":"); 
		
			   JFrame frame = new JFrame("Reception en cours");
			    JProgressBar pb = new JProgressBar();
		     
			    pb.setValue(0);
		        pb.setStringPainted(true);
		 
		        // add progress bar
		        frame.setLayout(new FlowLayout());
		        frame.getContentPane().add(pb);
		        // add progress bar
		        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        frame.setSize(300, 200);
		        frame.setVisible(true);
		     
		        
				FileSystemView fsv = FileSystemView.getFileSystemView();
				JFileChooser fileChooserSaveImage = new JFileChooser(fsv.getRoots()[0]);
				fileChooserSaveImage.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int retour = fileChooserSaveImage.showSaveDialog(null);
				if (retour == JFileChooser.APPROVE_OPTION) {
					File url = fileChooserSaveImage.getSelectedFile();
					if (url == null)
						try {
							soc.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					String f = null;
						f = tt.nextToken();
					

					dossierenregistrement = url.getAbsolutePath() + File.separator;
					nomFichier = dossierenregistrement + f;

					taillefichier = Integer.parseInt(tt.nextToken());
				
			}

			
			try {
				FileOutputStream out = null;

				out = new FileOutputStream(nomFichier);

				byte data[] = new byte[64000];

				int tail = 123;
				write.write((int) tail);// pour signaler qu'on est pret �
											// recevoir

				long compteur = 0;
				int taille = 0;

				while (((taille = read.read(data)) != -1)) {
					compteur += taille;
					out.write(data, 0, taille);
					pb.setValue((int) ((100 * compteur) / ((taillefichier != 0) ? taillefichier : 1)));
				}

				out.close();
		 
			} catch (SocketException e) {
				JOptionPane.showMessageDialog(null,
						("Communication interronpu"));
				new File(nomFichier).delete();
				try {
					this.soc.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			frame.dispose();
				JOptionPane
						.showMessageDialog(null,
								(new StringBuilder(
										"reception termin\351e "))
												.append((new File(nomFichier)).getAbsolutePath())
												.toString());

				int y = JOptionPane.showConfirmDialog(null, (new StringBuilder("voulez vous ouvrir le fichier:"))
						.append((new File(nomFichier)).getName()).append("?").toString());
				if (y == 0 && Desktop.isDesktopSupported()
						&& Desktop.getDesktop().isSupported(java.awt.Desktop.Action.OPEN))
					try {
						Desktop.getDesktop().open(new File(nomFichier));// pour
																		// l'ouvrir
					} catch (IOException ioexception) {
					}
			yield();
		} catch (Exception e) {
			try {
				this.soc.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
