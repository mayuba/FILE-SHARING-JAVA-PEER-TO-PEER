package Bill.partageFichier;

import java.awt.FlowLayout;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;

public class ServeurProcessus extends Thread {
	String file = null, add = null;

	private static final int defaut = 64000; 
	
	public ServeurProcessus(String file, String add) {
		this.file = file;
		this.add = add;
		start();
	}
 
	public void run() {
		Transfert(file, add, 100);
		yield();
		stop();

	}

	public static boolean Transfert(String file, String host, int type) {

		File fichier = null;
		fichier = new File(file);
		Socket s = null;// = new Socket();
		OutputStream out = null;// = new OutputStream();
		BufferedInputStream response = null;
		try {
			int portdest = defaut;
			s = new Socket(host, portdest);
			response = new BufferedInputStream(s.getInputStream());
			out = s.getOutputStream();
			// response[j] = new BufferedInputStream(s[j].getInputStream());
			// out[j] = s[j].getOutputStream();
		} catch (ConnectException e) {
			JOptionPane.showMessageDialog(null, "Destination non connect�");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long sizef = 0;
		sizef = fichier.length();

		String Conten = null;
		if (type == 100)
			Conten = fichier.getName() + ":" + sizef;

		System.out.println("paquet � envoyer:" + Conten);
		byte nameFile[] = Conten.getBytes();// recuperation du nom du fichier

		if (s.isConnected())
			try {
				out.write(nameFile, 0, nameFile.length);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		try {
			response.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		byte donnee[] = new byte[defaut];
		long compteurcourant = 0;

		int size;

		InputStream in = null;
		try {
			in = fichier.toURL().openStream();
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JFrame frame = new JFrame("Envoi en cours");
		JProgressBar pb = new JProgressBar();

		pb.setValue(0);
		pb.setStringPainted(true);

		// add progress bar
		frame.setLayout(new FlowLayout());
		frame.getContentPane().add(pb);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 200);
		frame.setVisible(true);
		try {
			while ((size = in.read(donnee)) != -1) 
			{
				compteurcourant += size;
				if (s.isConnected())
					out.write(donnee, 0, size);
				pb.setValue((int) ((100 * compteurcourant) / sizef));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame.dispose();
		try {
			out.flush();
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;

	}
 

}
