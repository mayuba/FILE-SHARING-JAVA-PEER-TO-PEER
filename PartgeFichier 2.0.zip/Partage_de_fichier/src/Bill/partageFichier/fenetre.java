package Bill.partageFichier;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.StringTokenizer;

import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.plaf.FileChooserUI;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JList;
import java.awt.*;
import java.io.*;

public class fenetre implements ActionListener, WindowListener {

	private JFrame frame;
	private JTextField FileName;
	private JButton add;
	private JList list;
	private JButton btnEnvoyer;
	File fichier;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fenetre window = new fenetre();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public fenetre() {
		initialize();
		 /*ENVOIFICHIER panel = new ENVOIFICHIER();
		 try {
			 panel.initialisation(null, null);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		  //JButton pross=null;
		 // JLabel chaine=null;
		new ClientProcessus(64000);//, chaine, pross);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 746, 578);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(0, 0, 162, 518);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(161, 0, 569, 518);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		FileName = new JTextField();
		FileName.setBounds(114, 83, 235, 32);
		panel_1.add(FileName);
		FileName.setColumns(10);

		add = new JButton("Add");
		add.setBounds(376, 88, 89, 23);
		panel_1.add(add);
		add.addActionListener(this);

		list = new JList();
		list.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		list.setBounds(76, 162, 389, 145);
		panel_1.add(list);

		btnEnvoyer = new JButton("Send");
		btnEnvoyer.setBounds(209, 342, 102, 32);
		panel_1.add(btnEnvoyer);
		btnEnvoyer.addActionListener(this);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenu mnSetting = new JMenu("Setting");
		menuBar.add(mnSetting);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == add) {
			JFileChooser dialogue = new JFileChooser(new File("."));
			if (dialogue.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				fichier = dialogue.getSelectedFile();
				FileName.setText(fichier.getName()); 
			}
		}
		if (e.getSource() == btnEnvoyer) {
			//String host[] = (String[]) null;
			//host = new String[1];
			String host = "0.0.0.0";
			new ServeurProcessus(fichier.toString(), host);
		}
		 
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}
}
