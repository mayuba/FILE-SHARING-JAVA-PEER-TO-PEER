package Bill.partageFichier;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.plaf.FileChooserUI;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JList;
import java.awt.*;
import java.io.*;
import java.net.BindException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;

public class fenetre implements ActionListener, WindowListener {

	private JFrame frame;
	private JFrame annonce;
	private JFrame barProgress;
	private JTextField FileName;
	private JButton add;
	private JButton btnEnvoyer;
	private JProgressBar progressBar;
	private JTextField IPclient;
	private JTextField textField_1;
	private JButton btnConnecter;
	private int port;
	private JLabel portlabel;
	private JLabel state;
	public JList<String> list;
	Container contentpane;
	JButton btnOk;
	String select;
	JPanel pane;
	JLabel myip;
	String host = " ";
	JLabel lblIp;
	File fichier = null;
	private JPanel panelBar;
	private JTextArea outputTextArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fenetre window = new fenetre();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public fenetre() {
		initialize();
		/*
		 * ENVOIFICHIER panel = new ENVOIFICHIER(); try {
		 * panel.initialisation(null, null); } catch (IOException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace(); }
		 */
		// JButton pross=null;
		// JLabel chaine=null;
		 
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Send File");
		frame.setBounds(100, 100, 673, 280);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		annonce = new JFrame();
		annonce.setTitle("Choix Ip");
		annonce.setBounds(300, 100, 300, 400);
		annonce.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		annonce.getContentPane().setLayout(null);
		annonce.setVisible(true);
		
		barProgress = new JFrame();
		barProgress.setTitle("Transfert");
		barProgress.setBounds(300, 100, 481, 216);
		barProgress.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		barProgress.getContentPane().setLayout(null);

		panelBar = new JPanel();
		panelBar.setBounds(10, 11, 445, 155);
		barProgress.getContentPane().add(panelBar);
		panelBar.setLayout(null);

		JButton btnAnnuler = new JButton("Annuler");
		btnAnnuler.setBounds(173, 121, 89, 23);
		panelBar.add(btnAnnuler);

		JLabel lblFichiertaille = new JLabel("Fichier ,Taille");
		lblFichiertaille.setBounds(85, 25, 273, 23);
		panelBar.add(lblFichiertaille);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(0, 0, 231, 213);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		textField_1 = new JTextField();
		textField_1.setBounds(35, 107, 126, 24);
		panel.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(72, 79, 26, 24);
		panel.add(lblPort);

		myip = new JLabel("ip conteneur\r\n");
		myip.setFont(new Font("Tahoma", Font.BOLD, 14));
		myip.setBackground(Color.WHITE);
		myip.setBounds(10, 24, 211, 24);
		panel.add(myip);
		myip.setText("My ip : ");
		btnConnecter = new JButton("Connecter");
		btnConnecter.setBounds(35, 143, 126, 24);
		panel.add(btnConnecter);

		portlabel = new JLabel("My port :");
		portlabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		portlabel.setBackground(Color.WHITE);
		portlabel.setBounds(10, 54, 151, 24);
		panel.add(portlabel);

		state = new JLabel();
		state.setForeground(Color.RED);
		state.setFont(new Font("Tahoma", Font.BOLD, 14));
		state.setBackground(Color.WHITE);
		state.setBounds(35, 178, 110, 24);
		panel.add(state);
		state.setText("No Connected");

		btnConnecter.addActionListener(this);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(232, 0, 419, 213);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		FileName = new JTextField();
		FileName.setBounds(46, 100, 235, 32);
		panel_1.add(FileName);
		FileName.setColumns(10);

		add = new JButton("Add");
		add.setBounds(318, 105, 89, 23);
		panel_1.add(add);
		add.addActionListener(this);

		btnEnvoyer = new JButton("Send");
		btnEnvoyer.setBounds(117, 150, 102, 32);
		panel_1.add(btnEnvoyer);

		IPclient = new JTextField();
		IPclient.setBounds(117, 22, 164, 32);
		panel_1.add(IPclient);
		IPclient.setColumns(10);

		lblIp = new JLabel("IP Client");
		lblIp.setBounds(46, 22, 50, 32);
		panel_1.add(lblIp);

		JLabel lblSelectionneUnFichier = new JLabel("Selectionne un fichier");
		lblSelectionneUnFichier.setBounds(117, 62, 136, 32);
		panel_1.add(lblSelectionneUnFichier);
		btnEnvoyer.addActionListener(this);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenu mnSetting = new JMenu("Setting");
		menuBar.add(mnSetting);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		contentpane = annonce;
		annonce.getContentPane().setLayout(null);
		extractionIP();

		btnOk = new JButton("OK");
		btnOk.setBounds(79, 216, 92, 36);
		btnOk.addActionListener(this);
		annonce.getContentPane().add(btnOk);

		panel = new JPanel();
		panel.setBounds(10, 20, 229, 185);
		annonce.getContentPane().add(panel);
		panel.setLayout(null);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 229, 184);
		panel.add(scrollPane);
		 list = new JList<String>(listExtend);
		scrollPane.setViewportView(list);
		list.setSelectedIndex(0);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		select = (String) list.getSelectedValue();
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				// contentpane.setBackground(listColorValues[list.getSelectedIndex()]);
				select = (String) list.getSelectedValue();
			}
		});
 
		annonce.setSize(265, 318);
		 

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == add) {
			JFileChooser dialogue = new JFileChooser(new File("."));
			if (dialogue.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				fichier = dialogue.getSelectedFile();
				FileName.setText(fichier.getName());
			}
		}
		if (e.getSource() == btnEnvoyer) {
			// String host[] = (String[]) null;
			// host = new String[1];
			String host = IPclient.getText().trim();
			new ServeurProcessus(fichier.toString(), host);
		}
		if (e.getSource() == btnOk) {
			System.out.println(select);
			StringTokenizer message = new StringTokenizer(select, ":");
			message.nextToken();
			host = message.nextToken();
			myip.setText("My ip : " + host);
			annonce.dispose();
			 
				 
					try {
						new ClientProcessus(64000);
					} catch (BindException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				 
			 // , chaine, pross);
		}

	}

	public static String[] extractionIP()  {
		String name = null;
		String concat = "";
		boolean interrupteur = false;
		 
		try {
			StringTokenizer	message = new StringTokenizer(getLocalAddress().toString(), ",");
		 
		ArrayList<String> newliste = new ArrayList<String>();
		while (message.hasMoreTokens()) {
			String c = message.nextToken();

			if (c.contains("%")) {
				StringTokenizer caract = new StringTokenizer(c, "%");
				caract.nextToken();
				name = caract.nextToken();
				if (interrupteur == true) {
					// System.out.println(caract.nextToken());
					newliste.add(name + " :" + concat);
					// System.out.println(name);
					interrupteur = false;
				}
			} else {
				if (!c.contains(":") && !c.contains("127.0.0.1")) {
					interrupteur = true;
					concat = c;
				}
			}

		}
		
		listExtend = new String[newliste.size()];

		System.out.println("----------------------liste des mes ip-------------------");
		// System.out.println(extraction().size());
		for (int i = 0; i < newliste.size(); i++) {
			System.out.println(newliste.get(i));
			listExtend[i] = newliste.get(i);
		}
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listExtend;
	}

	public static ArrayList<String> liste = new ArrayList<String>();
	private static String[] listExtend;

	public static ArrayList<String> getLocalAddress() throws SocketException {

		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		while (e.hasMoreElements()) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<InetAddress> ee = n.getInetAddresses();

			while (ee.hasMoreElements()) {
				InetAddress i = ee.nextElement();
				liste.add(i.getHostAddress());

			}
		}

		return liste;
	}

	public void fenetre_Transmission() {
		progressBar = new JProgressBar();
		progressBar.setBounds(69, 59, 311, 27);
		panelBar.add(progressBar);
		progressBar.setValue(0);
		progressBar.setStringPainted(true);
		outputTextArea = new JTextArea("", 5, 20);
		panelBar.add(progressBar);
		panelBar.add(outputTextArea);
		barProgress.setVisible(true);
	}

	int i = 0;

	public void transmissionBar(long progress, long size) {
		i++;
		System.out.println((int) ((100 * progress) / ((size != 0) ? size : 1)));
		// progressBar.setValue((int)progress);
		progressBar.setValue((int) ((100 * progress) / ((size != 0) ? size : 1)));
		// progressBar.setString(progressBar.getValue() + "%");
		// outputTextArea.setText(outputTextArea.getText()
		// + String.format("Completed %d%% of task.\n", progress));
		System.out.println(i + " taille de fichier recu");
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}
}
