package Bill.partageFichier;

import java.awt.Desktop;
import java.io.*;
import java.net.Socket;
import java.util.*;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.filechooser.FileSystemView;

// Referenced classes of package TCP:
//            ThreadEnvoi

public class Reception extends Thread {
	private Socket soc;
	private OutputStream write;
	//JLabel chaine = null;
	//JProgressBar pros = null;
	private BufferedInputStream read;
	private String copy;
	private String fileName;
	private String path = null;
	Hashtable<String, String> listeDossierEncours = null;
	//Vector<String> listereception = null;
	long size = 0;

	public Reception(Socket soc, Hashtable<String, String> listeDossierEncours//, JLabel chaine
			//, JProgressBar pros
			//,Vector<String> listereception
			) throws IOException {
		//this.listereception = listereception;
		//this.pros = pros;
		this.soc = soc;
		read = new BufferedInputStream(this.soc.getInputStream());
		write = soc.getOutputStream();
		this.listeDossierEncours = listeDossierEncours;
		//this.chaine = chaine;
		start();
	}

	 
	public void run() {
		try {
			byte b[] = new byte[1000];
			try {
				read.read(b);
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			// selection du dossier d'enregistrement
			String etat = null;
			copy = (new String(b, 0, b.length)).trim();//on renvoie une copie au propre
			System.out.println(copy);
			// System.out.println(copy);
			/*if (copy.lastIndexOf(":") < 2) {
				yield();
				stop();
				System.out.println("lastindexof est inferieur a 2");
			}
			*/
			 StringTokenizer message = new StringTokenizer(copy, ":"); 
			/*
			   if (copy.startsWith("DOS_:")) {
			 
				System.out.println("nous sommes dans le dos");
				tt.nextToken();
				etat = tt.nextToken();
				 if (etat.compareToIgnoreCase("DEBUT") == 0) {
					// FileSystemView fsv = FileSystemView.getFileSystemView();
					System.out.println("debut");
					try {
						JFileChooser fileChooserSaveImage = new JFileChooser(
								FileSystemView.getFileSystemView().getRoots()[0]);
						fileChooserSaveImage.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);// pour
																									// afficher
																									// que
																									// les
																									// dossiers
						int retour = fileChooserSaveImage.showSaveDialog(null);
						if (retour == JFileChooser.APPROVE_OPTION) {
							File url = fileChooserSaveImage.getSelectedFile();

							String dossier = tt.nextToken();

							path = url.getAbsolutePath() + File.separator;
							listeDossierEncours.put(dossier, path);
							String Sous = tt.nextToken();
							Sous += File.separator;
							fileName = Sous;

						}
					} catch (Exception e) {//
						try {
							soc.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						yield();
						stop();
					}
				} else if (etat.compareToIgnoreCase("EN_COURS") == 0) {
					System.out.println("en cours");
					path = this.listeDossierEncours.get(tt.nextToken());
					fileName = tt.nextToken();
				} else if (etat.compareToIgnoreCase("FIN") == 0) {
					System.out.println("fin");
					String dossier = tt.nextToken();

					path = this.listeDossierEncours.get(dossier);

					listeDossierEncours.remove(dossier);
					fileName = tt.nextToken();
				}
 
				String fi = tt.nextToken();

				taillefichier = Integer.parseInt(tt.nextToken());
				String doc = path + fileName;

				File file = new File(doc);
				if (!file.exists()) {
					String hh = path;
					tt = new StringTokenizer(fileName, "\\");
					while (tt.hasMoreTokens()) {
						hh += tt.nextToken();
						if (!new File(hh).exists())
							new File(hh).mkdir();
						hh += File.separator;
						System.out.println(hh);
					}
				}
				fileName = path + fileName + File.separator + fi;
				// System.out.println(this.fileName);

			} else {*/
				 
				FileSystemView fsv = FileSystemView.getFileSystemView();
				JFileChooser fileChooserSaveImage = new JFileChooser(fsv.getRoots()[0]);
				fileChooserSaveImage.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int retour = fileChooserSaveImage.showSaveDialog(null);
				if (retour == JFileChooser.APPROVE_OPTION) {
					File doc = fileChooserSaveImage.getSelectedFile();
					if (doc == null)
						try {
							soc.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					String file = null;
					/*if (!copy.startsWith("F_:")){
						f = tt.nextToken();// pour la version anterieure
						System.out.println("la version d'avant");
					}
					else {*/
						//tt.nextToken();
						file = message.nextToken();
					//}

					path = doc.getAbsolutePath() + File.separator;
					fileName = path + file;

					size = Integer.parseInt(message.nextToken());
				//}
			}

			//listereception.add(new File(fileName).getName());
			try {
				FileOutputStream out = null;

				out = new FileOutputStream(fileName);

				byte data[] = new byte[64000];

				//int tail = 123;
				write.write(1);// pour signaler qu'on est pret �
											// recevoir
				 
				long compteur = 0;
				int taille = 0;

				while (((taille = read.read(data)) != -1)) {

					compteur += taille;

					out.write(data, 0, taille);
					//pros.setValue((int) ((100 * compteur) / ((taillefichier != 0) ? taillefichier : 1)));
					//pros.setString(pros.getValue() + "%");
				}
				//out.write(taille);

				out.close();
				/*chaine.setText(chaine.getText() + (new StringBuilder("<br><h1>NOM FICHIER  Rec\347u:"))
						.append(fileName).append("<br>Expediteur:").append(soc.getInetAddress())
						.append(" <br>Date de reception:").append((new Date()).toGMTString()).append("</h1>")
						.toString());
				*/
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,
						("<html>cette erreur s'est produite:<br>" + e + "<br>appuyer <h1>OK</h1> pour  continuer"));
				new File(fileName).delete();
				try {
					this.soc.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			//if (!copy.startsWith("DOS_:")) {
				JOptionPane
						.showMessageDialog(null,
								(new StringBuilder(
										"<html><h3>reception termin\351e</h3><br><h3>nom du fichier :</h3><h2>"))
												.append((new File(fileName)).getAbsolutePath()).append("</h2></html>")
												.toString());

				int y = JOptionPane.showConfirmDialog(null, (new StringBuilder("voulez vous ouvrir le fichier:"))
						.append((new File(fileName)).getName()).append("?").toString());
				if (y == 0 && Desktop.isDesktopSupported()
						&& Desktop.getDesktop().isSupported(java.awt.Desktop.Action.OPEN))
					try {
						Desktop.getDesktop().open(new File(fileName));// pour
																		// l'ouvrir
					} catch (IOException ioexception) {
					}

			//} 
		/*else if (etat.compareToIgnoreCase("FIN") == 0) {
				int y = JOptionPane.showConfirmDialog(null,
						(new StringBuilder("voulez vous ouvrir la dossier d'enregistrement:"))
								.append((new File(fileName).getParent())));
				if (y == 0 && Desktop.isDesktopSupported()
						&& Desktop.getDesktop().isSupported(java.awt.Desktop.Action.OPEN))
					try {
						Desktop.getDesktop().open(new File(path));// pour
																					// l'ouvrir
					} catch (IOException ioexception) {
					}

			}*/
			// pros.setValue(0);
			yield();
		} catch (Exception e) {
			try {
				this.soc.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
