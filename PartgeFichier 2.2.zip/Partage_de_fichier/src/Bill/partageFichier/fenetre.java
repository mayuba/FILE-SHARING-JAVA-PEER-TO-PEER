package Bill.partageFichier;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.StringTokenizer;

import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileSystemView;
import javax.swing.plaf.FileChooserUI;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JList;
import java.awt.*;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class fenetre implements ActionListener, WindowListener {

	private JFrame frame;
	private JTextField FileName;
	private JButton add;
	private JButton btnEnvoyer;
	File fichier;
	private JTextField textField;
	private JTextField textField_1;
	private JButton btnConnecter;
	private int port;
	private JLabel portlabel;
	private JLabel state;
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					fenetre window = new fenetre();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public fenetre() {
		initialize();
		/*
		 * ENVOIFICHIER panel = new ENVOIFICHIER(); try {
		 * panel.initialisation(null, null); } catch (IOException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace(); }
		 */
		// JButton pross=null;
		// JLabel chaine=null;
		 
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 631, 277);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(0, 0, 190, 213);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		textField_1 = new JTextField();
		textField_1.setBounds(35, 107, 126, 24);
		panel.add(textField_1);
		textField_1.setColumns(10);

		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(72, 79, 26, 24);
		panel.add(lblPort);

		JLabel myip = new JLabel("ip conteneur\r\n");
		myip.setFont(new Font("Tahoma", Font.BOLD, 14));
		myip.setBackground(Color.WHITE);
		myip.setBounds(10, 24, 151, 24);
		panel.add(myip);
		try {
			InetAddress ip = InetAddress.getLocalHost();
			myip.setText("My ip : " + ip.getHostAddress());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		btnConnecter = new JButton("Connecter");
		btnConnecter.setBounds(35, 143, 126, 24);
		panel.add(btnConnecter);

		portlabel = new JLabel("My port :");
		portlabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		portlabel.setBackground(Color.WHITE);
		portlabel.setBounds(10, 54, 151, 24);
		panel.add(portlabel);
		
		state = new JLabel();
		state.setForeground(Color.RED);
		state.setFont(new Font("Tahoma", Font.BOLD, 14));
		state.setBackground(Color.WHITE);
		state.setBounds(35, 178, 110, 24);
		panel.add(state);
		state.setText("No Connected");
		
		btnConnecter.addActionListener(this);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(194, 0, 417, 213);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		FileName = new JTextField();
		FileName.setBounds(46, 100, 235, 32);
		panel_1.add(FileName);
		FileName.setColumns(10);

		add = new JButton("Add");
		add.setBounds(318, 105, 89, 23);
		panel_1.add(add);
		add.addActionListener(this);

		btnEnvoyer = new JButton("Send");
		btnEnvoyer.setBounds(117, 150, 102, 32);
		panel_1.add(btnEnvoyer);

		textField = new JTextField();
		textField.setBounds(117, 22, 164, 32);
		panel_1.add(textField);
		textField.setColumns(10);

		JLabel lblIp = new JLabel("IP Client");
		lblIp.setBounds(46, 22, 50, 32);
		panel_1.add(lblIp);

		JLabel lblSelectionneUnFichier = new JLabel("Selectionne un fichier");
		lblSelectionneUnFichier.setBounds(117, 62, 136, 32);
		panel_1.add(lblSelectionneUnFichier);
		btnEnvoyer.addActionListener(this);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenu mnSetting = new JMenu("Setting");
		menuBar.add(mnSetting);

		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == add) {
			JFileChooser dialogue = new JFileChooser(new File("."));
			if (dialogue.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				fichier = dialogue.getSelectedFile();
				FileName.setText(fichier.getName());
			}
		}
		if (e.getSource() == btnEnvoyer) { 
			String host = "0.0.0.0";
			new ServeurProcessus(fichier.toString(), host);
		}

		if (e.getSource() == btnConnecter) { 
			
			portlabel.setText("My port : "+textField_1.getText());
			setPort(Integer.parseInt(textField_1.getText()));
			new ClientProcessus(getPort());// , chaine, pross);
			state.setText("Connected");
			state.setForeground(Color.GREEN);
		}

	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}
}
